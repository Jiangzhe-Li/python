import paramiko
  
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect("172.16.137.188",22,"root", "centos")
stdin, stdout, stderr = ssh.exec_command("ls")
print stdout.readlines()
ssh.close()