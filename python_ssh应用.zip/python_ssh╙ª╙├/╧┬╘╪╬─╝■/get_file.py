import paramiko
  
t = paramiko.Transport(("172.16.137.188",22))
t.connect(username = "root", password = "centos")
sftp = paramiko.SFTPClient.from_transport(t)
remotepath='/tmp/test.txt'
localpath='test.txt'
sftp.get(remotepath, localpath)
t.close()